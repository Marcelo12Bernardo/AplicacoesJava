//Escreva um programa que imprima todos os numeros inteiros de 200 a 100 (em ordem decrescente).

public class EscreveNumerosInteiros {
    public static void main(String[] args) {

        System.out.println("Programa para escrever os inteiros entre 100 e 200, em ordem decrescente !");

        for(int i=200;i>=100;i--)
        {
            System.out.println(i);
        }
    }
}
