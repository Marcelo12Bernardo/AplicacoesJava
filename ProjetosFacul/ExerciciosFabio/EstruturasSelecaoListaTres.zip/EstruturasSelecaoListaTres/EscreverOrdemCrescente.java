//Dados tres valores A, B e C, construa um programa, que imprima os valores 
//de forma ascendente (do menorpara o maior).

import java.util.Scanner;

public class EscreverOrdemCrescente {
    public static void main(String[] args) {

		Scanner leitorDoTeclado = new Scanner(System.in);
		int valorA,valorB,valorC; 

	    System.out.println("Programa para escrever numeros em ordem crescente!");
	    System.out.print("Informe o primeiro numero: ");
	    valorA = leitorDoTeclado.nextInt();
        System.out.print("Informe o segundo numero: ");
	    valorB = leitorDoTeclado.nextInt();
        System.out.print("Informe o terceiro numero: ");
	    valorC = leitorDoTeclado.nextInt();

        
	}
    
}
